package com.example.abdulkadir.abdulkadir_mpdcoursework;

//StudentName:Abdulkadir Abdulrehman
//        StudentID           S1712579
//        MPD: Coursework
//        program of study:computing

public class ListItemObject {

    String title;
    String date;
    double Magnitude;
    int Depth;



    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public double getMagnitude() { return Magnitude; }
    public void setMagnitude(double magnitude) { Magnitude = magnitude; }
    public int getDepth() { return Depth; }
    public void setDepth(int depth) { Depth = depth; }
}
